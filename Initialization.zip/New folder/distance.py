#Program to calculate distance
#Motseo Bradley
#2024/02/29

value=(input("Enter the travel time:\n"))
t=eval(value)

g=9.80

d=  g*t**2/2

if t >= 0:
    print("The distance travelled is %.2f"%d)
else:
    print("The travel time must be zero or more.")