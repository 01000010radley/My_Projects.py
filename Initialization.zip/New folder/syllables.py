#Program to count syllables in a word
#Motseo Bradley
#29/03/2024


def is_vowel(letter):
    # Function to check if a letter is a vowel
    vowels = 'aeiouy'
    return letter.lower() in vowels

def next_vowel(word, index):
    # Function to find the index of the next vowel in a word starting from a given index
    for i in range(index, len(word)):
        if is_vowel(word[i]):
            return i
    return -1

def count_syllables(word):
    # Function to count the number of syllables in a word
    if not word:
        return 0
    count = 0
    i = next_vowel(word, 0)
    while i != -1:
        count = count + 1
        i = next_vowel(word, i + 1) if i + 1 < len(word) else -1
    # Handling silent 'e' at the end of the word
    if word.endswith(('e', 'es')) and not word.endswith(('le', 'les')) and not is_vowel(word[-2]) and count > 1:
        count = count - 1
    # Handling special cases like "ou" and "au"
    if word.startswith(('ou', 'au')):
        count += 1
    # Handling words starting with 'y' as a consonant
    if word[0] == 'y':
        count = count - 1
    return max(count, 1)

def main():
    # Main function to take user input and display syllable count
    while True:
        word = input('Enter a word (or \'q\' to quit):\n').lower()
        if word == 'q':
            break
        print(f'The word \'{word}\' has {count_syllables(word)} syllables.')
        print()

if __name__ == '__main__':
    main()