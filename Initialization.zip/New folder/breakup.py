#Program to convert date format from (yyyy-mm-dd hh:mm) to time in pm/am, day, month name, year
#Motseo Bradley
#29 March 2024

time = input('Enter the date and time (yyyy-mm-dd hh:mm):\n')
if time[0] == " ":
    time=time[1:]


if len(time) < 16:
    print('Enter a valid date in the format (yyyy-mm-dd hh:mm)')
else:    
    year, month, day, hours, minutes = time[0:4], time[5:7], time[8:10], time[11:13], time[14:16] #str type

    year = int(year)
    month = int(month)
    day_suff = int(day)
    day = int(day)
    hours = int(hours)
    minutes = int(minutes)

    if (0 <= hours < 24) and (0 <= minutes < 60) and (1 <= month <= 12) and (1 <= day <= 31):
        newyear = year%100
        
        month_names = { 1: "January",2: "February", 3: "March",4: "April",5: "May",6: "June",7: "July",8: "August", 9: "September",10: "October",11: "November", 12: "December"}
    
        month_name = month_names[month]
        if day in (11, 12, 13):
            day_suffix = "th"
        else:
            last_digit = day % 10
            day_suffixes = {1: 'st', 2: 'nd', 3: 'rd'}
            day_suffix = day_suffixes.get(last_digit, "th")
        newday = str(day) + day_suffix
            
        if 1<= hours <= 11 and 0<= minutes <= 59:
            newtime = (f'0{hours}:0{minutes} am')
            
        elif hours == 12 and 0<= minutes <= 59:
            newtime = (f"{hours:2}:{minutes} pm")
        
        elif  13 <= hours <= 23 and 0 <= minutes <= 59:
            newtime = (f'{(hours - 12):2}:{minutes} pm')
            
        elif hours == 0 and  0 <= minutes <= 59:
            newtime = (f'12:{minutes} am')
            
        print(f'{newtime} on the {newday} of {month_name} \'{newyear}')