#Program to change a sentence into a wordlist
#Motseo Bradley
#29/ 03/ 2024 

sentence = input('Enter a sentence:\n').lower()

word_list  = []

space_index = -1

while space_index != len(sentence):
    new_space = sentence.find(' ',space_index+1)
    
    if new_space != -1 :
            word = sentence[space_index+1:new_space]
            
    else:
        word = sentence[space_index+1:]
        
    word_list.append(word)  
    
    space_index = new_space if new_space != -1 else len(sentence)


words = ''
for i in range(len(word_list)):
    if i == 0:
        words += word_list[i]
    else:
        words += ', ' + word_list[i]

print(f'The word list: {words}.')