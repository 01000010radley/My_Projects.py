# My very first program to display Hello World on screen
#Motseo Bradley
#Date: 22 February 2024

print ("Hello World")