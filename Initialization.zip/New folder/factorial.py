#Program to print the factorial(!) of a number
#Motseo Bradley
#14 March 2024

n = int(input('Enter an integer value:\n'))
factorial = 1
if n > 0:
    for j in range(1, n+1):
        factorial = factorial * j
    print(f'The value of {n}! is {factorial}.')
elif n < 0:
        print('The value must be zero or more.')
else:
    print('The value of 0! is 1.')
