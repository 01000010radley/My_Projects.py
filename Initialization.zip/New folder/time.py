#Program to calculate distance
#Motseo Bradley
#2024/02/29

hours = input("Enter the hours:\n")
minutes = input("Enter the minutes:\n")
seconds = input("Enter the seconds:\n")

if 0<=eval(hours)<=24 and 0<=eval(minutes)<=59 and 0<=eval(seconds)<=59 :
    print("Your time is valid.")
else:
    print("Your time is invalid.")