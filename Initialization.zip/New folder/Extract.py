#Program EXTRACT information form raw data
#Motseo Bradley
#06/04/2024

def location(block):
    #Find the index of the comma and space seperating the coordinates
    sep_x = block.find(',')
    sep_y = block.find(' ',sep_x)
    #Entering the location from the block which is reversed
    reversed_location = block[sep_y:block.find('END')-1]
    #reversing the reversed string and capitalizing
    reformatted_location = reversed_location[::-1].title()
    
    return reformatted_location
   
    
def temperature(block):
    #Find the index in which the temperature lies in the block
    space_index = block.find(' ')
    space_index2 = block.find('_',space_index + 1)
    #convert the str into a float
    temp = eval(block[space_index: space_index2])
    
    return temp
    
def x_coordinate(block):
    #Find the index of the characters in which x_coordinate lies between
    sep1 = block.find(':')
    sep2 = block.find(',')
    coordinate_X = block[sep1 + 1: sep2 ]
    
    return  coordinate_X 

def y_coordinate(block):
    #Find the index of the characters in which y_coordinate lies between
    separator = block.find(',')
    separator2 = block.find(' ', separator)
    coordinate_Y = block[separator + 1: separator2]
    
    return coordinate_Y

def pressure(block):
     #Find the index of the characters in which the nmbers for pressure lies between
    sep_index1 = block.find('_')
    sep_index2 = block.find(':')
    pressure_data = float(block[sep_index1+1: sep_index2])
    
    return pressure_data

def get_block(data):
    #Extra the data that is going to be evaluated and used
    begin_index = data.find('END')
    end_index = data.find('BEGIN')
    block = data[end_index : begin_index + 3]
    
    return block
    
def main():
    data = input('Enter the raw data:\n')
    block = get_block(data)
    print('Site information:')
    print('Location:', location(block))
    print('Coordinates:', y_coordinate(block), x_coordinate(block))
    print('Temperature: {:.2f} C'.format(temperature(block)))
    print('Pressure: {:.2f} hPa'.format(pressure(block)))

if __name__=='__main__':
    main()