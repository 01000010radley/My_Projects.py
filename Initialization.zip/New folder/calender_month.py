#Program to display a calender given the month and the year
#Motseo Bradley
#06/04/2024

import math

def day_of_week(day, month, year):
    # If the month is January or February, convert it to months 13 and 14 of the previous year
    if month < 3:
        month = month + 12
        year = year - 1
    # Zeller's Congruence algorithm to calculate the day of the week
    h = (day + math.floor((13 * (month + 1)) / 5) + year + math.floor(year / 4) - math.floor(year / 100) + math.floor(year / 400)) % 7
    return (h + 5) % 7 + 1  # Adjust the result to match Monday=1, ..., Sunday=7

def is_leap(year):
    # Check if the year is a leap year
    return (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0)

def month_num(month_name):
    # Convert month name to month number
    month_name = month_name.lower().capitalize()
    month_number = {"January": 1, "February": 2, "March": 3, "April": 4, "May": 5, "June": 6,
                    "July": 7, "August": 8, "September": 9, "October": 10, "November": 11, "December": 12}
    return month_number.get(month_name, -1)  # Return -1 if month name is invalid

def num_days_in(month_num, year):
    # Return the number of days in a given month
    if month_num in {1, 3, 5, 7, 8, 10, 12}:
        return 31
    elif month_num in {4, 6, 9, 11}:
        return 30
    elif month_num == 2:
        return 29 if is_leap(year) else 28  # February has 29 days if it's a leap year, otherwise 28
    else:
        return -1  # Return -1 for invalid month number

def main():
    # Prompt user to input month and year
    month_name = input('Enter month:\n')
    year = int(input('Enter year:\n'))

    # Convert month name to month number
    month_number = month_num(month_name)
    if month_number == -1:
        print("Invalid month name.")
        return

    print(month_name.title())
    print("Mo Tu We Th Fr Sa Su")
    
    # Calculate the first day of the month and the number of days in the month
    first_day_of_month = day_of_week(1, month_number, year)
    days_in_month = num_days_in(month_number, year)
    
    # Print spaces to align the starting day of the month
    print('  ' * (first_day_of_month - 1), end=' ')
    
    # Iterate through the days of the month and print them with proper formatting
    for i in range(1, days_in_month + 1):
        print(f'{i:2}', end=" ")  # Print day with leading space if necessary
        if (i + first_day_of_month - 1) % 7 == 0:
            print()  # Add newline after printing each row of the calendar
    print()  # Print an empty line after the calendar

if __name__=='__main__':
    main()