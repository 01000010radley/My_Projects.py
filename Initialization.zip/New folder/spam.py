#Program generate personalised spam message
#Motseo Bradley
#01/03/2024

first_name = input("Enter first name:\n")
last_name = input("Enter last name:\n")
sum_of_money= input("Enter sum of money in USD:\n")
Country = input("Enter country name:\n")
percentage_cut = eval(sum_of_money)//100 * 30
s=round(percentage_cut,2)


print('')
print("Dearest",first_name)
print("It is with a heavy heart that I inform you of the death of my father,")
print(f"General Fayk {last_name}, your long lost relative from Mapsfostol.")
print(f"My father left the sum of {sum_of_money}USD for us, your distant cousins.")
print(f"Unfortunately, we cannot access the money as it is in a bank in {Country}.")
print("I desperately need your assistance to access this money.")
print(f"I will even pay you generously, 30% of the amount - {float(s)}USD,")
print("for your help.  Please get in touch with me at this email address asap.")
print("Yours sincerely")
print("Frank",last_name)